package com.ex.bluechat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Set;

public class People extends AppCompatActivity {
    private ListView paired;
    private ListView available;
    private ProgressBar progressBar;
    private ArrayAdapter<String> adapter_available_devices;
    private ArrayAdapter<String> adapter_paired_devies;
    private BluetoothAdapter bluetoothAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_people);
        paired = findViewById(R.id.paired);
        available = findViewById(R.id.available);
        progressBar = findViewById(R.id.progressBar);
        init();
        showAvailableDevice();
    }

    private void init() {
        adapter_paired_devies = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        paired.setAdapter(adapter_paired_devies);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        Set<BluetoothDevice> paired_ones = bluetoothAdapter.getBondedDevices();
        if(paired_ones != null && paired_ones.size() > 0){
            for(BluetoothDevice device:paired_ones){
                adapter_paired_devies.add(device.getName()+"\n"+device.getAddress());
            }
        }

        paired.setOnItemClickListener((parent, view, position, id) -> {
            String info = ((TextView) view).getText().toString();
            String address = info.substring(info.length() - 17);

            Intent intent = new Intent();
            intent.putExtra("deviceAddress", address);
            setResult(RESULT_OK, intent);
            finish();
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.two,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.show_p:
                scanDevices();
                return true;
            default: return super.onOptionsItemSelected(item);
        }

    }

    private void scanDevices() {
        progressBar.setVisibility(View.GONE);
        adapter_available_devices.clear();
        Toast.makeText(this,"Scanning",Toast.LENGTH_SHORT).show();
        if(bluetoothAdapter.isDiscovering()){
            bluetoothAdapter.cancelDiscovery();
        }
        bluetoothAdapter.startDiscovery();
    }

    private void showAvailableDevice() {
//        scanDevices();
        adapter_available_devices = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        available.setAdapter(adapter_available_devices);

       bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
       IntentFilter intentFilter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(bluetoothDeviceListener,intentFilter);
        IntentFilter intentFilter1 = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(bluetoothDeviceListener,intentFilter1);

       available.setOnItemClickListener((parent, view, position, id) -> {
            String info = ((TextView) view).getText().toString();
            String address = info.substring(info.length() - 17);

           Intent intent = new Intent();
           intent.putExtra("deviceAddress", address);
           setResult(RESULT_OK, intent);
           finish();
       });
    }

    private BroadcastReceiver bluetoothDeviceListener = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(BluetoothDevice.ACTION_FOUND.equals(action)){
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if(device.getBondState() != BluetoothDevice.BOND_BONDED){
                    adapter_available_devices.add(device.getName()+"\n"+device.getAddress());
                }
            }
            else if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){
                progressBar.setVisibility(View.GONE);
                if(adapter_available_devices.getCount() == 0){
                    Toast.makeText(context,"No new devices found",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(context,"Click on the device to start the chat",Toast.LENGTH_SHORT).show();
                }
            }

        }
    };
}